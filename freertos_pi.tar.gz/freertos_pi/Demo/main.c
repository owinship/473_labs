//main.c
//authored by Jared Hull
//
//tasks 1 and 2 blink the ACT LED
//main initialises the devices and IP tasks 

#include <FreeRTOS.h>
#include <task.h>

#include "interrupts.h"
#include "gpio.h"
#include "video.h"
#include "FreeRTOS_IP.h"
#include "FreeRTOS_Sockets.h"

void task1() {
	int i;
	while(1) {
		vTaskDelay(10);
		SetGpio(4,1);
		vTaskDelay(10);
		SetGpio(4,0);
		for(i=1;i<27;i++)
		{
			SetGpio(i, 1);
			vTaskDelay(2);
			SetGpio(i, 0);

		}
	}
}

int main(void) {
	int i;
	for(i=0;i<27;i++)
		SetGpioFunction(i, 1);			// RDY led

	initFB();



	DisableInterrupts();
	InitInterruptController();

	xTaskCreate(task1, "LED_0", 128, NULL, 0, NULL);

	//set to 0 for no debug, 1 for debug, or 2 for GCC instrumentation (if enabled in config)
	loaded = 1;

	vTaskStartScheduler();

	/*
	 *	We should never get here, but just in case something goes wrong,
	 *	we'll place the CPU into a safe loop.
	 */
	while(1) {
		;
	}
}
